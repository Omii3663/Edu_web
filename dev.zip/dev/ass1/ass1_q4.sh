#!/bin/bash

# Check if a hostname or IP address is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <hostname_or_ip>"
    exit 1
fi

# Input hostname or IP address
host="$1"

# Perform a ping test
if ping -c 1 -W 2 "$host" > /dev/null 2>&1; then
    # If reachable, log a success message
    logger -p user.info "Network check success: Host $host is reachable at $(date)"
    echo "Success: Host $host is reachable."
else
    # If not reachable, log a failure message
    logger -p user.error "Network check failure: Host $host is not reachable at $(date)"
    echo "Failure: Host $host is not reachable."
fi

