#!/bin/bash

# Function to check if a number is prime
is_prime() {
    local num=$1
    
    # A prime number is greater than 1
    if [ "$num" -le 1 ]; then
        echo "false"
        return
    fi

    # Check divisors from 2 to the square root of the number
    for ((i = 2; i * i <= num; i++)); do
        if ((num % i == 0)); then
            echo "false"
            return
        fi
    done

    echo "true"
}

# Prompt the user for a number
read -p "Enter a number to check if it is prime: " number

# Validate that the input is a non-negative integer
if ! [[ "$number" =~ ^[0-9]+$ ]]; then
    echo "Error: Please enter a valid non-negative integer."
    exit 1
fi

# Call the function and display the result
if [ "$(is_prime "$number")" == "true" ]; then
    echo "$number is a prime number."
else
    echo "$number is not a prime number."
fi

