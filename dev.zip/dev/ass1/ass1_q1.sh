
#!/bin/bash

# Display the current date and time
echo "Current Date and Time: $(date)"

# Display the name of the logged-in user
echo "Logged-in User: $USER"

# Display the name of the shell being used
echo "Shell in Use: $SHELL"

# End of script

