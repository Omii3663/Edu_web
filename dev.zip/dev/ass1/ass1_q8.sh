#!/bin/bash

# Directory to monitor (default to current directory if not provided)
dir_to_monitor="${1:-.}"

# Size limit in MB
size_limit=500

# Log file
log_file="/home/userlog"

# Ensure the log file exists
touch "$log_file"

# Function to calculate the directory size
get_dir_size_mb() {
    du -sm "$dir_to_monitor" | awk '{print $1}'
}

# Monitor the directory size
dir_size=$(get_dir_size_mb)

# Check if the directory size exceeds the limit
if ((dir_size > size_limit)); then
    # Log a warning message with size and time
    echo "$(date): WARNING! Directory $dir_to_monitor size ($dir_size MB) exceeded limit ($size_limit MB)" >> "$log_file"
    echo "WARNING: Directory size exceeded the limit. Check $log_file for details."
else
    echo "Directory size is within the limit ($dir_size MB)."
fi

