#!/bin/bash

# Directory to search (default to current directory if not specified)
search_dir="${1:-.}"

# Report file
report_file="error_report.txt"

# Clear or create the report file
> $report_file

# Recursively search for .txt files and process them
find "$search_dir" -type f -name "*.txt" | while read -r file; do
    # Count lines containing the word "error" (case-insensitive)
    error_count=$(grep -i -c "error" "$file")
    
    # Append the file name and count to the report file
    echo "$file: $error_count" >> $report_file
done

# Display the report file contents
cat $report_file

