#!/bin/bash

# Output file
output_file="multiplication_table.txt"

# Create or clear the output file
> $output_file

# Generate the multiplication table using nested loops
for num in {1..5}; do
    echo "Multiplication Table for $num" >> $output_file
    for multiplier in {1..10}; do
        result=$((num * multiplier))
        echo "$num x $multiplier = $result" >> $output_file
    done
    echo "" >> $output_file
done

# Display the contents of the file
cat $output_file

