src_dir="/home/sam/Documents/devope/ass1"    # Replace with the actual source directory path
backup_dir="/home/sam/Documents/devope/ass1"  # Replace with the actual backup destination path
log_file="/home/sam/Documents/devope/ass1backup.log"

# Ensure the log file exists
touch "$log_file"

# Get the current date and time for backup file naming
current_date=$(date +%Y-%m-%d_%H-%M-%S)

# Check if the source directory exists
if [ ! -d "$src_dir" ]; then
    echo "$(date): ERROR: Source directory $src_dir does not exist." >> "$log_file"
    exit 1
fi

# Check if the backup destination directory exists, create it if not
if [ ! -d "$backup_dir" ]; then
    echo "$(date): ERROR: Backup destination directory $backup_dir does not exist. Creating it." >> "$log_file"
    mkdir -p "$backup_dir"
    if [ $? -ne 0 ]; then
        echo "$(date): ERROR: Failed to create backup destination directory $backup_dir." >> "$log_file"
        exit 1
    fi
fi

# Create the backup file name with timestamp
backup_file="$backup_dir/backup_$current_date.tar.gz"

# Run the tar command to create an incremental backup (only files modified in the last 24 hours)
tar --create --gzip --file="$backup_file" --newer-than="24 hours ago" "$src_dir"

# Check if tar command succeeded
if [ $? -eq 0 ]; then
    echo "$(date): Backup successful. Backup file created: $backup_file" >> "$log_file"
else
    echo "$(date): ERROR: Backup failed for $src_dir." >> "$log_file"
    exit 1
fi

