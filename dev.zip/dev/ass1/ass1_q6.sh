#!/bin/bash

# Check if a log file is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <log_file>"
    exit 1
fi

# Input log file
log_file="$1"

# Check if the file exists
if [ ! -f "$log_file" ]; then
    echo "Error: File $log_file not found."
    exit 1
fi

# Output file for extracted information
output_file="extracted_info.log"

# Clear or create the output file
> $output_file

# Define regular expressions
ip_regex='([0-9]{1,3}\.){3}[0-9]{1,3}'
datetime_regex='\[[0-9]{2}/[A-Za-z]{3}/[0-9]{4}:[0-9]{2}:[0-9]{2}:[0-9]{2} [+-][0-9]{4}\]'
error_regex='(error|ERROR|Error)'

# Process the log file
while read -r line; do
    # Extract IP address, validate, and extract other information
    if [[ $line =~ $ip_regex ]]; then
        ip="${BASH_REMATCH[0]}"
        
        # Validate the IP address
        if [[ $ip =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
            # Check each octet
            valid=true
            for octet in ${ip//./ }; do
                if ((octet < 0 || octet > 255)); then
                    valid=false
                    break
                fi
            done
            
            if $valid; then
                datetime=$(echo "$line" | grep -oP "$datetime_regex")
                error_message=$(echo "$line" | grep -ioP "$error_regex.*")
                
                echo "IP: $ip, Date-Time: $datetime, Error: $error_message" >> $output_file
            fi
        fi
    fi
done < "$log_file"

# Display the extracted information
cat $output_file

