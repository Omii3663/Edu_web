#!/bin/bash

# Check if the number of iterations is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <number_of_iterations>"
    exit 1
fi

# Number of iterations
iterations=$1

# Log file for CPU usage
log_file="cpu_usage.log"

# Clear or create the log file
> $log_file

echo "Monitoring CPU usage for $iterations iterations..."
echo "Log file: $log_file"

# Monitor CPU usage
for ((i = 1; i <= iterations; i++)); do
    # Get the current CPU usage using top
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')

    # Check CPU usage and apply logic
    if (( $(echo "$cpu_usage < 10" | bc -l) )); then
        # Skip logging if CPU usage is below 10%
        echo "Iteration $i: CPU usage ($cpu_usage%) below 10%, skipping logging."
        continue
    elif (( $(echo "$cpu_usage > 90" | bc -l) )); then
        # Stop monitoring if CPU usage exceeds 90%
        echo "Iteration $i: CPU usage ($cpu_usage%) exceeds 90%, stopping monitoring."
        echo "$(date): CPU usage $cpu_usage% exceeded 90%. Monitoring stopped." >> $log_file
        break
    fi

    # Log CPU usage
    echo "$(date): CPU usage is $cpu_usage%." >> $log_file
    echo "Iteration $i: CPU usage logged ($cpu_usage%)."

    # Wait 1 second before the next iteration
    sleep 1
done

echo "Monitoring complete. Check the log file for details."

