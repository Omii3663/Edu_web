#!/bin/bash

# Check if a CSV file is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <employee_data.csv>"
    exit 1
fi

# Input CSV file
csv_file="$1"

# Check if the file exists
if [ ! -f "$csv_file" ]; then
    echo "Error: File $csv_file not found."
    exit 1
fi

# Temporary file for processing
temp_file="processed_employees.tmp"

# Skip header row and process the data
tail -n +2 "$csv_file" > "$temp_file"

# Calculate the average salary for each department
echo "Average Salary by Department:"
awk -F, '
{
    dept[$2] += $3;
    count[$2]++;
}
END {
    for (d in dept) {
        printf "%s: %.2f\n", d, dept[d] / count[d];
    }
}
' "$temp_file"

echo

# Identify employees with more than 5 years in the company
echo "Employees with more than 5 years in the company:"
awk -F, -v current_year=$(date +%Y) '
{
    join_year = substr($4, 1, 4); # Extract year from Join Date
    years_with_company = current_year - join_year;
    if (years_with_company > 5) {
        print $1 " (" years_with_company " years)";
    }
}
' "$temp_file"

# Clean up temporary file
rm -f "$temp_file"

