import socket

# Replace 
HOST = '16.171.175.230'
PORT = 12345

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect((HOST, PORT))
        data = client_socket.recv(1024)
        print("Latest Uptime Info from Server:\n")
        print(data.decode('utf-8'))

if __name__ == "__main__":
    main()
