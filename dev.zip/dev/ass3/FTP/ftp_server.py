# ftp_server.py
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

def run_ftp_server():
    authorizer = DummyAuthorizer()
    # Allow anonymous login with read-only access
    authorizer.add_anonymous(homedir='.', perm='elr')  # 'e': change directory, 'l': list, 'r': retrieve (download)

    handler = FTPHandler
    handler.authorizer = authorizer

    server = FTPServer(("127.0.0.1", 2121), handler)
    print("FTP Server started on ftp://127.0.0.1:2121")
    server.serve_forever()

if __name__ == "__main__":
    run_ftp_server()

