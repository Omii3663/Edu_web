# ftp_client.py
from ftplib import FTP

ftp = FTP()
ftp.connect("127.0.0.1", 2121)
ftp.login("dhanashree","Samu@8459")  # Anonymous login

filename = "uptime_data.tsv"

# Download the file
with open(filename, "wb") as f:
    ftp.retrbinary(f"RETR {filename}", f.write)

ftp.quit()

# Read and display the latest uptime info
with open(filename, "r") as file:
    lines = file.readlines()[1:]  # Skip header
    if lines:
        print("Latest Uptime Info:", lines[-1].strip())
    else:
        print("No uptime data found.")

