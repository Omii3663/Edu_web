
import socket

SERVER_IP = '16.171.175.230'
PORT = 5001

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    message = "get_uptime"
    s.sendto(message.encode(), (SERVER_IP, PORT))
    data, _ = s.recvfrom(1024)

print("Latest Uptime Info:", data.decode())

