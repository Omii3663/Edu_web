
import socket

def get_latest_uptime():
    try:
        with open("uptime_data.tsv", "r") as file:
            lines = file.readlines()[1:]  # Skip header
            return lines[-1].strip() if lines else "No data"
    except Exception as e:
        return f"Error: {e}"

HOST = '0.0.0.0'  
PORT = 5001       

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.bind((HOST, PORT))
    print(f"UDP Server listening on {HOST}:{PORT}")
    
    while True:
        data, addr = s.recvfrom(1024)
        print(f"Received request from {addr}")
        uptime_info = get_latest_uptime()
        s.sendto(uptime_info.encode(), addr)

