#vi ass3_tsv.sh
#chmod +x ass3_tsv.sh
#./ass3_tsv.sh

#code
FILE="uptime_data.tsv"

# Header
if [ ! -f "$FILE" ]; then
    echo -e "Timestamp\tUptime" > "$FILE"
fi

# Infinite loop
while true; do
    # Get current timestamp and uptime
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
    UPTIME=$(uptime -p | sed 's/up //')

    # Write to temporary file
    echo -e "${TIMESTAMP}\t${UPTIME}" >> "$FILE"

    # Sort the file in descending order of timestamp
    (head -n 1 "$FILE" && tail -n +2 "$FILE" | sort -r) > temp && mv temp "$FILE"

    # Wait for 5 minutes (300 seconds)
    sleep 300
done
