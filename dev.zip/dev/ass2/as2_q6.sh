#!/bin/bash
#Print the system uptime
uptime -p
